package entity.shipping;

public class Shipment {
    
    public void validateDeliveryInfo(){
        // TODO: implement later on
    }

    public Shipment createNewShipment(){
        // TODO: implement later on
        return new Shipment();
    }
}
